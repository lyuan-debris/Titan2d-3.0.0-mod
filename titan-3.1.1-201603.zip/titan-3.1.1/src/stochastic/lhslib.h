#include "../useful/useful_lib.h"

int uniformlhs(int Nstart, int Nref, int **refnum, double **samples);
int normallhs(int Nstart, int Nref, int **refnum, double **samples);

