C*******************************************************************
C* Copyright (C) 2003 University at Buffalo
C*
C* This software can be redistributed free of charge.  See COPYING
C* file in the top distribution directory for more details.
C*
C* This software is distributed in the hope that it will be useful,
C* but WITHOUT ANY WARRANTY; without even the implied warranty of
C* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
C*
C* Author: 
C* Description: 
C*
C*******************************************************************
C* $Id: rnr.h 2 2003-08-13 19:26:11Z sorokine $ 
C*/

          implicit none
c     X will be the down-slope direction -- keep consistent with savage
c     for now, flat surface

          double precision half,pi

          parameter (half=0.5d0, pi=3.1415926535897931)


